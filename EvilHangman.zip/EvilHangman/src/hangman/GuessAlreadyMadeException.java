package hangman;

public class GuessAlreadyMadeException extends Exception {
}
